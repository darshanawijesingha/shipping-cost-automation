import pdfplumber
import pandas as pd
import re
import uuid
import os
from pathlib import Path

def run_zellco(c_pdf, w_pdf):
    """
    Process Zellco PDFs and save to Excel
    
    Args:
        c_pdf: Path to C.pdf (can be relative or absolute)
        w_pdf: Path to W.pdf (can be relative or absolute)
    
    Returns:
        Absolute path to the created Excel file
    """
    
    # ============================================================================
    # GET ABSOLUTE PATHS
    # ============================================================================
    
    # Convert input paths to absolute paths
    c_pdf = os.path.abspath(c_pdf)
    w_pdf = os.path.abspath(w_pdf)
    
    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Go up one level to the flask web app root
    app_root = os.path.dirname(script_dir)
    # Define outputs directory as absolute path
    outputs_dir = os.path.join(app_root, "outputs")
    
    # Create outputs directory if it doesn't exist
    os.makedirs(outputs_dir, exist_ok=True)
    
    print(f"Script directory: {script_dir}")
    print(f"App root: {app_root}")
    print(f"Outputs directory: {outputs_dir}")
    print(f"Processing C.pdf: {c_pdf}")
    print(f"Processing W.pdf: {w_pdf}")
    
    # ============================================================================
    # PART 1: Extract tax data from C.pdf (DUTY AMOUNT and RATES)
    # ============================================================================

    def extract_first_page_table(pdf):
        """Extract data from first page using simple pattern matching"""
        first_page = pdf.pages[0]
        text = first_page.extract_text()
        lines = text.split('\n')
        
        # Extract Item Number and HS Code
        item_no = '1'
        hs_code = ''
        
        for i, line in enumerate(lines):
            if 'Item No.' in line:
                for j in range(i, min(i+5, len(lines))):
                    data_line = lines[j]
                    pattern = re.search(r'(\d+)\s+(\d{8})\s*(\d{2})', data_line)
                    if pattern:
                        item_no = pattern.group(1)
                        hs_code = pattern.group(2) + pattern.group(3)
                        break
        
        # Extract tax table entries
        tax_entries = []
        
        for line in lines:
            clean_line = ' '.join(line.split())
            if re.match(r'^(CID|PAL|SSL|VAT|EIC)\s+[\d,]+\s+[\d.]+\s+[\d,]+\s+\d+', clean_line):
                parts = clean_line.split()
                if len(parts) >= 5:
                    tax_entries.append({
                        'Item_Number': item_no,
                        'HS_Code': hs_code,
                        'Type': parts[0],
                        'Tax_Base': parts[1],
                        'Rate': parts[2],
                        'Amount': parts[3],
                        'MP': parts[4]
                    })
        
        df = pd.DataFrame(tax_entries)
        
        if not df.empty:
            df['Tax_Base'] = df['Tax_Base'].str.replace(',', '').astype(float)
            df['Amount'] = df['Amount'].str.replace(',', '').astype(float)
            df['Rate'] = df['Rate'].astype(float)
            df['MP'] = df['MP'].astype(int)
        
        return df

    def parse_side_by_side_tables(text):
        """Parse text where two tax tables appear side by side on the same lines"""
        
        lines = text.split('\n')
        all_entries = []
        items_found = {}
        
        tax_block_lines = []
        in_tax_block = False
        
        for line in lines:
            if 'Type Tax base Rate Amount MP' in line or 'ation of\ntaxes' in line or line.strip().startswith('ation of'):
                in_tax_block = True
                tax_block_lines = []
                continue
            
            if in_tax_block:
                has_null = re.search(r'null\s+(\d+)', line)
                
                if has_null or 'Summary of Taxes' in line or 'Total Page' in line:
                    tax_block_lines.append(line)
                    in_tax_block = False
                    entries, items = parse_tax_block(tax_block_lines)
                    all_entries.extend(entries)
                    items_found.update(items)
                else:
                    tax_block_lines.append(line)
        
        return all_entries, items_found

    def parse_tax_block(lines):
        """Parse a block of tax lines that may contain side-by-side tables"""
        
        entries = []
        items_info = {}
        
        tax_pattern = r'(CID|PAL|SSL|VAT|EIC)\s+([\d,]+)\s+([\d.]+)\s+([\d,]+)\s+(\d+)'
        
        tax_entries_left = []
        tax_entries_right = []
        null_markers = []
        
        for line in lines:
            all_taxes = list(re.finditer(tax_pattern, line))
            nulls = list(re.finditer(r'null\s+(\d+)\s+([\d,]+)', line))
            
            if len(all_taxes) >= 1:
                tax_entries_left.append({
                    'type': all_taxes[0].group(1),
                    'tax_base': all_taxes[0].group(2),
                    'rate': all_taxes[0].group(3),
                    'amount': all_taxes[0].group(4),
                    'mp': all_taxes[0].group(5)
                })
            
            if len(all_taxes) >= 2:
                tax_entries_right.append({
                    'type': all_taxes[1].group(1),
                    'tax_base': all_taxes[1].group(2),
                    'rate': all_taxes[1].group(3),
                    'amount': all_taxes[1].group(4),
                    'mp': all_taxes[1].group(5)
                })
            
            for null in nulls:
                null_markers.append({
                    'item_no': null.group(1),
                    'total': null.group(2),
                    'position': null.start()
                })
        
        null_markers.sort(key=lambda x: x['position'])
        
        if len(null_markers) >= 1:
            for tax in tax_entries_left:
                entries.append({
                    'Item_Number': null_markers[0]['item_no'],
                    'Type': tax['type'],
                    'Tax_Base': tax['tax_base'],
                    'Rate': tax['rate'],
                    'Amount': tax['amount'],
                    'MP': tax['mp']
                })
        
        if len(null_markers) >= 2:
            for tax in tax_entries_right:
                entries.append({
                    'Item_Number': null_markers[1]['item_no'],
                    'Type': tax['type'],
                    'Tax_Base': tax['tax_base'],
                    'Rate': tax['rate'],
                    'Amount': tax['amount'],
                    'MP': tax['mp']
                })
        
        return entries, items_info

    def extract_items_from_text(text):
        """Extract Item Number and HS Code from text"""
        items = {}
        pattern = r'Marks & Nos\s*\.?\s*(\d+)\s+(\d{8})\s*(\d{2})'
        
        for match in re.finditer(pattern, text):
            item_no = match.group(1)
            hs_code = match.group(2) + match.group(3)
            items[item_no] = hs_code
        
        return items

    # Extract tax data from C.pdf
    all_data_frames = []

    with pdfplumber.open(c_pdf) as pdf:
        # Process FIRST PAGE
        df_page1 = extract_first_page_table(pdf)
        if not df_page1.empty:
            all_data_frames.append(df_page1)
        
        # Process REMAINING PAGES
        if len(pdf.pages) > 1:
            all_entries = []
            all_items = {}
            
            for page_num in range(1, len(pdf.pages)):
                page = pdf.pages[page_num]
                text = page.extract_text()
                
                page_items = extract_items_from_text(text)
                all_items.update(page_items)
                
                entries, items_in_block = parse_side_by_side_tables(text)
                all_entries.extend(entries)
            
            # Map HS codes to entries
            for entry in all_entries:
                item_no_entry = entry['Item_Number']
                if item_no_entry in all_items:
                    entry['HS_Code'] = all_items[item_no_entry]
                else:
                    entry['HS_Code'] = 'UNKNOWN'
            
            if all_entries:
                df_remaining = pd.DataFrame(all_entries)
                df_remaining['Tax_Base'] = df_remaining['Tax_Base'].str.replace(',', '').astype(float)
                df_remaining['Amount'] = df_remaining['Amount'].str.replace(',', '').astype(float)
                df_remaining['Rate'] = df_remaining['Rate'].astype(float)
                df_remaining['MP'] = df_remaining['MP'].astype(int)
                all_data_frames.append(df_remaining)

    # Create combined tax dataframe
    if all_data_frames:
        combined_tax_df = pd.concat(all_data_frames, ignore_index=True)
        combined_tax_df['HS_Code'] = combined_tax_df['HS_Code'].apply(
            lambda x: x[:-2] if isinstance(x, str) and x.endswith('00') else x)
        
        # Create duty amount by HS Code (CID, PAL, EIC only)
        filtered_df = combined_tax_df[combined_tax_df['Type'].isin(['CID', 'PAL', 'EIC'])].copy()
        filtered_df['Amount_Ex_VAT'] = (filtered_df['Tax_Base'] * filtered_df['Rate'] / 100).round(2)
        duty_by_hs = filtered_df.groupby('HS_Code')['Amount_Ex_VAT'].sum().reset_index()
        duty_by_hs.columns = ['HS_Code', 'DUTY AMOUNT (EX. VAT)']
        
        # Create rate pivot table
        rate_pivot = combined_tax_df.pivot_table(
            index='HS_Code',
            columns='Type',
            values='Rate',
            aggfunc='first'
        ).reset_index()
        rate_pivot = rate_pivot.fillna(0)
        
        # Merge duty and rates
        final_tax_data = pd.merge(duty_by_hs, rate_pivot, on='HS_Code', how='outer')
        final_tax_data = final_tax_data.sort_values('HS_Code').reset_index(drop=True)
    else:
        final_tax_data = pd.DataFrame()

    # ============================================================================
    # PART 2: Extract working sheet data from W.pdf
    # ============================================================================

    # Extract text from W.pdf
    text = ""
    with pdfplumber.open(w_pdf) as pdf:
        for page in pdf.pages:
            text += page.extract_text() + "\n"

    # Parse the extracted text into DataFrame
    data_rows = []
    lines = text.strip().split('\n')

    i = 0
    current_hs_code = None

    while i < len(lines):
        line = lines[i].strip()
        
        # Look for HS code pattern (e.g., "4010.31." or "8413.30." or "8483.10.")
        hs_match = re.match(r'^(\d{4}\.\d{2}\.?\d{0,2}\.?)', line)
        if hs_match:
            current_hs_code = hs_match.group(1)
            i += 1
            
            while i < len(lines) and not lines[i].strip():
                i += 1
            
            if i < len(lines):
                data_line = lines[i].strip()
                
                if re.match(r'^\d+\.?\d*\s+\d+', data_line):
                    i += 1
                    continue
                
                data_line_clean = re.sub(r'(\d+),(\d+)', r'\1\2', data_line)
                
                desc_match = re.match(r'^(\d+\.[A-Z]+.*?)(?:\s+\d+[PCSKIT]+|\s+\d+\.?\d*\s+\d+[PCSKIT]*)', data_line_clean, re.IGNORECASE)
                if desc_match:
                    description = desc_match.group(1).strip()
                else:
                    parts = data_line_clean.split()
                    desc_parts = []
                    for part in parts:
                        if re.match(r'^\d+\.?\d*$', part) and not re.match(r'^\d+\.', part):
                            break
                        if part.upper() in ['PCS', 'KIT', 'SET']:
                            break
                        desc_parts.append(part)
                    description = ' '.join(desc_parts).strip()
                
                uom_match = re.search(r'(\d+)(PCS|KIT|SET)', data_line, re.IGNORECASE)
                uom = uom_match.group(2).upper() if uom_match else ''
                
                numbers = re.findall(r'(\d+\.?\d*)', data_line_clean)
                
                if numbers and re.match(r'^\d+$', numbers[0]) and len(numbers[0]) <= 3:
                    numbers = numbers[1:]
                
                if len(numbers) >= 9:
                    row = {
                        'hs_code': current_hs_code,
                        'description': description,
                        'pkgs': numbers[0],
                        'qty': numbers[1],
                        'uom': uom,
                        'gross': numbers[2],
                        'net': numbers[3],
                        'fob': numbers[4],
                        'freight': numbers[5],
                        'insurance': numbers[6],
                        'other': numbers[7],
                        'cif': numbers[8]
                    }
                    data_rows.append(row)
        
        else:
            if current_hs_code and re.search(r'\d+PCS|\d+\s+PCS|\d+KIT|\d+\s+KIT', line, re.IGNORECASE):
                data_line = line
                
                if re.match(r'^\d+\.?\d*\s+\d+', data_line):
                    i += 1
                    continue
                
                data_line_clean = re.sub(r'(\d+),(\d+)', r'\1\2', data_line)
                
                desc_match = re.match(r'^(\d+\.[A-Z]+.*?)(?:\s+\d+[PCSKIT]+|\s+\d+\.?\d*\s+\d+[PCSKIT]*)', data_line_clean, re.IGNORECASE)
                if desc_match:
                    description = desc_match.group(1).strip()
                else:
                    parts = data_line_clean.split()
                    desc_parts = []
                    for part in parts:
                        if re.match(r'^\d+\.?\d*$', part) and not re.match(r'^\d+\.', part):
                            break
                        if part.upper() in ['PCS', 'KIT', 'SET']:
                            break
                    description = ' '.join(desc_parts).strip()
                
                uom_match = re.search(r'(\d+)(PCS|KIT|SET)', data_line, re.IGNORECASE)
                uom = uom_match.group(2).upper() if uom_match else ''
                
                numbers = re.findall(r'(\d+\.?\d*)', data_line_clean)
                
                if numbers and re.match(r'^\d+$', numbers[0]) and len(numbers[0]) <= 3:
                    numbers = numbers[1:]
                
                if len(numbers) >= 9:
                    row = {
                        'hs_code': current_hs_code,
                        'description': description,
                        'pkgs': numbers[0],
                        'qty': numbers[1],
                        'uom': uom,
                        'gross': numbers[2],
                        'net': numbers[3],
                        'fob': numbers[4],
                        'freight': numbers[5],
                        'insurance': numbers[6],
                        'other': numbers[7],
                        'cif': numbers[8]
                    }
                    data_rows.append(row)
        
        i += 1

    # Create DataFrame from W.pdf
    df_w = pd.DataFrame(data_rows)

    # Convert numeric columns
    numeric_cols = ['pkgs', 'qty', 'gross', 'net', 'fob', 'freight', 'insurance', 'other', 'cif']
    for col in numeric_cols:
        if col in df_w.columns:
            df_w[col] = pd.to_numeric(df_w[col], errors='coerce')

    # Transform HS code to 8 digits
    def transform_hs_code(hs_code):
        if pd.isna(hs_code):
            return hs_code
        cleaned = hs_code.replace('.', '')
        if len(cleaned) < 8:
            cleaned = cleaned.ljust(8, '0')
        return cleaned

    if not df_w.empty:
        df_w['hs_code'] = df_w['hs_code'].apply(transform_hs_code)

        # Calculate TOTAL EXW - USD (sum of FOB by HS code)
        fob_sum_by_hs = df_w.groupby('hs_code')['fob'].sum().reset_index()
        fob_sum_by_hs.columns = ['HS Code', 'TOTAL EXW - USD']

        # Add TOTAL EXW - USD to working sheet
        df_w = df_w.merge(fob_sum_by_hs, left_on='hs_code', right_on='HS Code', how='left')
        df_w = df_w.drop('HS Code', axis=1)
    else:
        fob_sum_by_hs = pd.DataFrame()

    # ============================================================================
    # PART 3: MERGE BOTH DATASETS BY HS CODE
    # ============================================================================

    if not df_w.empty and not final_tax_data.empty:
        # Merge working sheet with tax data
        final_merged_df = df_w.merge(
            final_tax_data, 
            left_on='hs_code', 
            right_on='HS_Code', 
            how='left'
        )

        # Drop the duplicate HS_Code column (keep hs_code)
        final_merged_df = final_merged_df.drop('HS_Code', axis=1)

        # Reorder columns to put key fields first
        column_order = [
            'hs_code', 
            'description', 
            'TOTAL EXW - USD',
            'DUTY AMOUNT (EX. VAT)',
            'pkgs', 'qty', 'uom', 'gross', 'net', 'fob', 
            'freight', 'insurance', 'other', 'cif',
            'CID', 'PAL', 'SSL', 'VAT', 'EIC'
        ]
        # Only include columns that exist
        column_order = [col for col in column_order if col in final_merged_df.columns]
        final_merged_df = final_merged_df[column_order]
    else:
        final_merged_df = pd.DataFrame()

    # ============================================================================
    # EXPORT - USING ABSOLUTE PATH
    # ============================================================================
    
    # Create unique filename with absolute path
    unique_name = f"zellco_{uuid.uuid4()}.xlsx"
    output_file = os.path.join(outputs_dir, unique_name)
    
    print(f"Saving Excel file to: {output_file}")
    
    # Save to Excel
    try:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            if not final_merged_df.empty:
                final_merged_df.to_excel(writer, sheet_name='Merged_Working_Sheet_Tax', index=False)
            if not df_w.empty:
                df_w.to_excel(writer, sheet_name='Working_Sheet_Only', index=False)
            if not final_tax_data.empty:
                final_tax_data.to_excel(writer, sheet_name='Tax_Data_Only', index=False)
            if not fob_sum_by_hs.empty:
                fob_sum_by_hs.to_excel(writer, sheet_name='FOB_Summary_by_HS', index=False)
        
        # Verify file was created
        if os.path.exists(output_file):
            print(f"✅ File successfully created: {output_file}")
            print(f"File size: {os.path.getsize(output_file)} bytes")
        else:
            raise Exception(f"File was not created at {output_file}")
            
    except Exception as e:
        print(f"❌ Error saving Excel file: {str(e)}")
        raise
    
    # Return the absolute path
    return output_file