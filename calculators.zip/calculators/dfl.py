import pdfplumber
import pandas as pd
import re
import uuid
import os


def run_dfl(c_pdf, w_pdf):

    # ============================================================================
    # PART 1: Extract tax data from uploaded C.pdf
    # ============================================================================

    def extract_first_page_table(pdf):

        first_page = pdf.pages[0]

        text = first_page.extract_text()

        lines = text.split('\n')

        item_no = '1'
        hs_code = ''

        for i, line in enumerate(lines):

            if 'Item No.' in line:

                for j in range(i, min(i + 5, len(lines))):

                    data_line = lines[j]

                    pattern = re.search(
                        r'(\d+)\s+(\d{8})\s*(\d{2})',
                        data_line
                    )

                    if pattern:
                        item_no = pattern.group(1)
                        hs_code = pattern.group(2) + pattern.group(3)
                        break

        tax_entries = []

        for line in lines:

            clean_line = ' '.join(line.split())

            if re.match(
                r'^(CID|PAL|SSL|VAT|EIC)\s+[\d,]+\s+[\d.]+\s+[\d,]+\s+\d+',
                clean_line
            ):

                parts = clean_line.split()

                if len(parts) >= 5:

                    tax_entries.append({
                        'Item_Number': item_no,
                        'HS_Code': hs_code,
                        'Type': parts[0],
                        'Tax_Base': parts[1],
                        'Rate': parts[2],
                        'Amount': parts[3],
                        'MP': parts[4]
                    })

        df = pd.DataFrame(tax_entries)

        if not df.empty:

            df['Tax_Base'] = df['Tax_Base'].str.replace(',', '').astype(float)

            df['Amount'] = df['Amount'].str.replace(',', '').astype(float)

            df['Rate'] = df['Rate'].astype(float)

            df['MP'] = df['MP'].astype(int)

        return df


    def parse_side_by_side_tables(text):

        lines = text.split('\n')

        all_entries = []

        items_found = {}

        tax_block_lines = []

        in_tax_block = False

        for line in lines:

            if (
                'Type Tax base Rate Amount MP' in line
                or line.strip().startswith('ation of')
            ):

                in_tax_block = True
                tax_block_lines = []
                continue

            if in_tax_block:

                has_null = re.search(r'null\s+(\d+)', line)

                if has_null or 'Summary of Taxes' in line:

                    tax_block_lines.append(line)

                    in_tax_block = False

                    entries, items = parse_tax_block(
                        tax_block_lines
                    )

                    all_entries.extend(entries)

                    items_found.update(items)

                else:
                    tax_block_lines.append(line)

        return all_entries, items_found


    def parse_tax_block(lines):

        entries = []

        items_info = {}

        tax_pattern = (
            r'(CID|PAL|SSL|VAT|EIC)\s+'
            r'([\d,]+)\s+'
            r'([\d.]+)\s+'
            r'([\d,]+)\s+'
            r'(\d+)'
        )

        tax_entries_left = []

        tax_entries_right = []

        null_markers = []

        for line in lines:

            all_taxes = list(
                re.finditer(tax_pattern, line)
            )

            nulls = list(
                re.finditer(r'null\s+(\d+)\s+([\d,]+)', line)
            )

            if len(all_taxes) >= 1:

                tax_entries_left.append({
                    'type': all_taxes[0].group(1),
                    'tax_base': all_taxes[0].group(2),
                    'rate': all_taxes[0].group(3),
                    'amount': all_taxes[0].group(4),
                    'mp': all_taxes[0].group(5)
                })

            if len(all_taxes) >= 2:

                tax_entries_right.append({
                    'type': all_taxes[1].group(1),
                    'tax_base': all_taxes[1].group(2),
                    'rate': all_taxes[1].group(3),
                    'amount': all_taxes[1].group(4),
                    'mp': all_taxes[1].group(5)
                })

            for null in nulls:

                null_markers.append({
                    'item_no': null.group(1),
                    'total': null.group(2),
                    'position': null.start()
                })

        null_markers.sort(
            key=lambda x: x['position']
        )

        if len(null_markers) >= 1:

            for tax in tax_entries_left:

                entries.append({
                    'Item_Number': null_markers[0]['item_no'],
                    'Type': tax['type'],
                    'Tax_Base': tax['tax_base'],
                    'Rate': tax['rate'],
                    'Amount': tax['amount'],
                    'MP': tax['mp']
                })

        if len(null_markers) >= 2:

            for tax in tax_entries_right:

                entries.append({
                    'Item_Number': null_markers[1]['item_no'],
                    'Type': tax['type'],
                    'Tax_Base': tax['tax_base'],
                    'Rate': tax['rate'],
                    'Amount': tax['amount'],
                    'MP': tax['mp']
                })

        return entries, items_info


    def extract_items_from_text(text):

        items = {}

        pattern = (
            r'Marks & Nos\s*\.?\s*'
            r'(\d+)\s+'
            r'(\d{8})\s*'
            r'(\d{2})'
        )

        for match in re.finditer(pattern, text):

            item_no = match.group(1)

            hs_code = match.group(2) + match.group(3)

            items[item_no] = hs_code

        return items


    # ============================================================================
    # PROCESS C PDF
    # ============================================================================

    all_data_frames = []

    with pdfplumber.open(c_pdf) as pdf:

        df_page1 = extract_first_page_table(pdf)

        if not df_page1.empty:
            all_data_frames.append(df_page1)

    if all_data_frames:

        combined_tax_df = pd.concat(
            all_data_frames,
            ignore_index=True
        )

        combined_tax_df['HS_Code'] = (
            combined_tax_df['HS_Code'].apply(
                lambda x: (
                    x[:-2]
                    if isinstance(x, str)
                    and x.endswith('00')
                    else x
                )
            )
        )

        filtered_df = combined_tax_df[
            combined_tax_df['Type'].isin(
                ['CID', 'PAL', 'EIC']
            )
        ].copy()

        filtered_df['Amount_Ex_VAT'] = (
            filtered_df['Tax_Base']
            * filtered_df['Rate']
            / 100
        ).round(2)

        duty_by_hs = (
            filtered_df.groupby('HS_Code')
            ['Amount_Ex_VAT']
            .sum()
            .reset_index()
        )

        duty_by_hs.columns = [
            'HS_Code',
            'DUTY AMOUNT (EX. VAT)'
        ]

        rate_pivot = (
            combined_tax_df.pivot_table(
                index='HS_Code',
                columns='Type',
                values='Rate',
                aggfunc='first'
            )
            .reset_index()
        )

        rate_pivot = rate_pivot.fillna(0)

        final_tax_data = pd.merge(
            duty_by_hs,
            rate_pivot,
            on='HS_Code',
            how='outer'
        )

    else:

        final_tax_data = pd.DataFrame()


    # ============================================================================
    # SAMPLE W PDF PROCESS
    # Replace with your existing W parsing logic
    # ============================================================================

    df_w = pd.DataFrame({
        'HS_Code': ['401031'],
        'description': ['Sample Item'],
        'TOTAL EXW - USD': [100]
    })


    # ============================================================================
    # MERGE
    # ============================================================================

    final_merged_df = pd.merge(
        df_w,
        final_tax_data,
        on='HS_Code',
        how='left'
    )


    # ============================================================================
    # EXPORT
    # ============================================================================

    unique_name = f"dfl_{uuid.uuid4()}.xlsx"

    output_file = os.path.join(
        "outputs",
        unique_name
    )

    with pd.ExcelWriter(
        output_file,
        engine='openpyxl'
    ) as writer:

        final_merged_df.to_excel(
            writer,
            sheet_name='Merged_Working_Sheet_Tax',
            index=False
        )

        if not final_tax_data.empty:

            final_tax_data.to_excel(
                writer,
                sheet_name='Tax_Data_Only',
                index=False
            )

    return output_file